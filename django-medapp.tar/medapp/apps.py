from django.apps import AppConfig


class MedappConfig(AppConfig):
    name = 'medapp'
