from django.urls import path
from . import views
import os


app_name='medapp'

urlpatterns = [ 
	path('',views.index, name='index'),
	path('new_patient_registor/',views.new_patient_registor, name='new_registor'),
	path('Patient_history/',views.Patient_history, name='Patient_history'),
	path('registor/',views.registor, name='registor'),
	path('update/<int:id>/',views.update, name='update'),
	path('patient_update/<int:id>/',views.patient_update, name='patient_update')

]

